class Planet {
    
    var name: String
    var numberOfMoons: Int
    var orbitalPeriod: Double
    var hasLife: Bool
    
    init(name: String, numberOfMoons: Int, orbitalPeriod: Double, hasLife: Bool){
        self.name = name
        self.numberOfMoons = numberOfMoons
        self.orbitalPeriod = orbitalPeriod
        self.hasLife = hasLife
    
    }
    
    func planetInfo() {
        var moonNoun = "moon"
        if numberOfMoons != 1 {
            moonNoun = "moons"
        }
        
        var hasLifeString = "has life"
        if hasLife == false {
            hasLifeString = "does not have life"
        }
    
    print("\(self.name) has \(self.numberOfMoons) \(moonNoun).  Its orbit is \(self.orbitalPeriod) days and \(hasLifeString).")
    
    }
}

let earth2 = Planet(name: "Earth", numberOfMoons: 1, orbitalPeriod: 365.00, hasLife: true)

print(earth2)

print(earth2.numberOfMoons)

earth2.planetInfo()


